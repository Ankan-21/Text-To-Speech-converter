1. Create sample project to generate text of given audio file.
2. Save all uploaded audio file to s3 bucket.
3. Use google api provide the functionality to translate text generated from audio file to desired language.
4. Deploy project to Azure or AWS cloud Service.